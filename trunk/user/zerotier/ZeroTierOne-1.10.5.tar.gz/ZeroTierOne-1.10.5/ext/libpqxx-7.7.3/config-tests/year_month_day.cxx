// Test for std::chrono::year_month_day etc.
#include <chrono>

int main()
{
  return int(std::chrono::year{1});
}
